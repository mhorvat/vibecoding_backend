package com.deepseek.orders.service.impl;

import com.deepseek.orders.entity.OrderItem;
import com.deepseek.orders.repository.OrderItemRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderItemServiceImplTest {

    @Mock
    private OrderItemRepository orderItemRepository;

    @InjectMocks
    private OrderItemServiceImpl orderItemService;

    @Test
    void createOrderItem_ShouldReturnSavedOrderItem() {
        OrderItem orderItem = new OrderItem();
        when(orderItemRepository.save(any(OrderItem.class))).thenReturn(orderItem);

        OrderItem savedItem = orderItemService.createOrderItem(orderItem);

        assertNotNull(savedItem);
        verify(orderItemRepository, times(1)).save(orderItem);
    }

    @Test
    void getOrderItemById_ShouldReturnOrderItem() {
        Long itemId = 1L;
        OrderItem orderItem = new OrderItem();
        when(orderItemRepository.findById(itemId)).thenReturn(Optional.of(orderItem));

        OrderItem foundItem = orderItemService.getOrderItemById(itemId);

        assertNotNull(foundItem);
    }
}