package com.deepseek.orders.repository;

import com.deepseek.orders.entity.OrderItem;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@ActiveProfiles("test")
class OrderItemRepositoryTest {

    @Autowired
    private OrderItemRepository orderItemRepository;

    @Test
    void findByOrderId_ShouldReturnOrderItems() {
        OrderItem item = new OrderItem();
        orderItemRepository.save(item);

        List<OrderItem> items = orderItemRepository.findByOrderId(1L);

        assertThat(items).isNotEmpty();
    }
}
