package com.deepseek.orders.service;

import com.deepseek.orders.entity.Product;
import com.deepseek.orders.repository.ProductRepository;
import com.deepseek.orders.service.impl.ProductServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductServiceFilterTest {

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private ProductServiceImpl productService;

    @Test
    void filterProducts_ByCategoryAndPrice_ShouldReturnFilteredProducts() {
        String category = "ELECTRONICS";
        BigDecimal minPrice = BigDecimal.valueOf(1000);
        BigDecimal maxPrice = BigDecimal.valueOf(1500);
        Product product = new Product("Laptop", "High performance laptop", BigDecimal.valueOf(1200), category);

        when(productRepository.findByCategoryAndPriceBetween(category, minPrice, maxPrice))
                .thenReturn(List.of(product));

        List<Product> result = productService.filterProducts(category, minPrice, maxPrice);

        assertEquals(1, result.size());
        assertEquals("Laptop", result.get(0).getName());
    }

    @Test
    void getTop5BestSellingProducts_ShouldReturnProducts() {
        Product p1 = new Product("Laptop", "High performance laptop", BigDecimal.valueOf(1200), "ELECTRONICS");
        Product p2 = new Product("Mouse", "Wireless mouse", BigDecimal.valueOf(50), "ELECTRONICS");

        when(productRepository.findTop5BestSellingProducts())
                .thenReturn(List.of(new Object[]{p1, 10L}, new Object[]{p2, 5L}));

        List<Product> result = productService.getTop5BestSellingProducts();

        assertEquals(2, result.size());
        assertTrue(result.stream().anyMatch(p -> p.getName().equals("Laptop")));
    }
}
