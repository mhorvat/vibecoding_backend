package com.deepseek.orders.repository;

import com.deepseek.orders.entity.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@ActiveProfiles("test")
class OrderRepositoryTest {

    @Autowired
    private OrderRepository orderRepository;

    @Test
    void findByCustomerId_ShouldReturnPagedOrders() {
        Order order = new Order();
        orderRepository.save(order);

        Page<Order> page = orderRepository.findByCustomerId(1L, PageRequest.of(0, 10));

        assertThat(page).isNotNull();
    }
}
