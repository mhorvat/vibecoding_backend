package com.deepseek.orders.repository;

import com.deepseek.orders.entity.Product;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@ActiveProfiles("test")
class ProductRepositoryTest {

    @Autowired
    private ProductRepository productRepository;

    @Test
    void saveProduct_ShouldReturnSavedProduct() {
        Product product = new Product("Laptop", "High performance laptop", BigDecimal.valueOf(1200), "ELECTRONICS");

        Product savedProduct = productRepository.save(product);

        assertThat(savedProduct).isNotNull();
        assertThat(savedProduct.getId()).isNotNull();
        assertThat(savedProduct.getName()).isEqualTo("Laptop");
    }

    @Test
    void findByCategory_ShouldReturnProducts() {
        Product p1 = new Product("Laptop", "High performance laptop", BigDecimal.valueOf(1200), "ELECTRONICS");
        Product p2 = new Product("Mouse", "Wireless mouse", BigDecimal.valueOf(50), "ELECTRONICS");
        productRepository.save(p1);
        productRepository.save(p2);

        List<Product> electronics = productRepository.findByCategory("ELECTRONICS");

        assertThat(electronics).hasSize(2);
        assertThat(electronics).extracting(Product::getName).containsExactlyInAnyOrder("Laptop", "Mouse");
    }
}