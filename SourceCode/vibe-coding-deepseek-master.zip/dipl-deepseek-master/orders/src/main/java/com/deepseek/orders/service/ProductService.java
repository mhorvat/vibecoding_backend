package com.deepseek.orders.service;

import com.deepseek.orders.entity.Product;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public interface ProductService {
    Product createProduct(Product product);
    Product getProductById(Long id);
    List<Product> getAllProducts();
    List<Product> getProductsByCategory(String category);
    List<Product> searchProducts(String name);
    Product updateProduct(Long id, Product product);
    void deleteProduct(Long id);

    Map<Long, Long> getProductSalesStatistics();
    List<Product> filterProducts(String category, BigDecimal minPrice, BigDecimal maxPrice);
    List<Product> getAllProductsSorted(String sortDirection);
    List<Product> getTop5BestSellingProducts();
}