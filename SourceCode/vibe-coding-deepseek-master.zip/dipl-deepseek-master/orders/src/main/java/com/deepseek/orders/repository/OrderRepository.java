package com.deepseek.orders.repository;

import com.deepseek.orders.entity.Order;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByCustomerId(Long customerId);

    // Dohvat narudžbi po korisniku sa paginacijom
    Page<Order> findByCustomerId(Long customerId, Pageable pageable);
}
