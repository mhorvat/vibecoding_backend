package com.deepseek.orders.service.impl;

import com.deepseek.orders.entity.Product;
import com.deepseek.orders.repository.OrderItemRepository;
import com.deepseek.orders.repository.ProductRepository;
import com.deepseek.orders.service.ProductService;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import java.util.List;
import java.math.BigDecimal;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final OrderItemRepository orderItemRepository; // Dodana zavisnost

    public ProductServiceImpl(ProductRepository productRepository,
                              OrderItemRepository orderItemRepository) {
        this.productRepository = productRepository;
        this.orderItemRepository = orderItemRepository;
    }

    @Override
    public Product createProduct(Product product) {
        return productRepository.save(product);
    }

    @Override
    public Product getProductById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found with id: " + id));
    }

    @Override
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    @Override
    public List<Product> getProductsByCategory(String category) {
        return productRepository.findByCategory(category);
    }

    @Override
    public List<Product> searchProducts(String name) {
        return productRepository.findByNameContainingIgnoreCase(name);
    }

    @Override
    public Product updateProduct(Long id, Product productDetails) {
        Product product = getProductById(id);
        product.setName(productDetails.getName());
        product.setDescription(productDetails.getDescription());
        product.setPrice(productDetails.getPrice());
        product.setCategory(productDetails.getCategory());
        return productRepository.save(product);
    }

    @Override
    public void deleteProduct(Long id) {
        Product product = getProductById(id);
        productRepository.delete(product);
    }

    @Override
    public List<Product> filterProducts(String category, BigDecimal minPrice, BigDecimal maxPrice) {
        if (category != null && !category.isEmpty()) {
            return productRepository.findByCategoryAndPriceBetween(category, minPrice, maxPrice);
        } else {
            return productRepository.findByPriceBetween(minPrice, maxPrice);
        }
    }

    @Override
    public List<Product> getAllProductsSorted(String sortDirection) {
        Sort sort = Sort.by("price");
        if ("desc".equalsIgnoreCase(sortDirection)) {
            sort = sort.descending();
        } else {
            sort = sort.ascending();
        }
        return productRepository.findAll(sort);
    }

    @Override
    public List<Product> getTop5BestSellingProducts() {
        List<Object[]> results = productRepository.findTop5BestSellingProducts();
        return results.stream()
                .map(obj -> (Product) obj[0])
                .collect(Collectors.toList());
    }

    @Override
    public Map<Long, Long> getProductSalesStatistics() {
        List<Object[]> results = orderItemRepository.getProductSalesStatistics();
        return results.stream()
                .collect(Collectors.toMap(
                        obj -> (Long) obj[0],
                        obj -> (Long) obj[1]
                ));
    }
}
