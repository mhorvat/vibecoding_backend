package com.deepseek.orders.service;

import com.deepseek.orders.entity.Order;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface OrderService {
    Order createOrder(Order order);
    Order getOrderById(Long id);
    List<Order> getAllOrders();
    List<Order> getOrdersByCustomerId(Long customerId);
    Order updateOrder(Long id, Order order);
    void deleteOrder(Long id);

    Page<Order> getOrdersByCustomerId(Long customerId, Pageable pageable);
}
