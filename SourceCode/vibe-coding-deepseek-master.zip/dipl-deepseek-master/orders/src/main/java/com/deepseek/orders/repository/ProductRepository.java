package com.deepseek.orders.repository;

import com.deepseek.orders.entity.Product;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByCategory(String category);
    List<Product> findByNameContainingIgnoreCase(String name);

    // Filtriranje po cijeni i kategoriji
    List<Product> findByCategoryAndPriceBetween(String category, BigDecimal minPrice, BigDecimal maxPrice);

    // Filtriranje samo po cijeni
    List<Product> findByPriceBetween(BigDecimal minPrice, BigDecimal maxPrice);

    // Sortiranje
    List<Product> findAll(Sort sort);

    // Top 5 najprodavanijih proizvoda
    @Query("SELECT oi.product, SUM(oi.quantity) as totalQuantity " +
            "FROM OrderItem oi " +
            "GROUP BY oi.product " +
            "ORDER BY totalQuantity DESC LIMIT 5")
    List<Object[]> findTop5BestSellingProducts();
}
