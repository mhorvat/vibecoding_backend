package com.gemini.orders.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gemini.orders.dto.CustomerDTO;
import com.gemini.orders.service.CustomerService;
import com.gemini.orders.service.OrderService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CustomerController.class)
class CustomerControllerTest {
    @Autowired private MockMvc mockMvc;
    @Autowired private ObjectMapper objectMapper;
    @MockBean private CustomerService customerService;
    @MockBean private OrderService orderService; // Mocked because it's a dependency

    @Test
    void whenPostCustomer_withInvalidEmail_shouldReturnBadRequest() throws Exception {
        // GIVEN
        CustomerDTO invalidCustomer = new CustomerDTO(null, "Test", "neispravan-email");
        // WHEN & THEN
        mockMvc.perform(post("/api/v1/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalidCustomer)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void whenPostCustomer_withValidData_shouldReturnCreated() throws Exception {
        // GIVEN
        CustomerDTO validDTO = new CustomerDTO(null, "Test", "test@test.com");
        CustomerDTO savedDTO = new CustomerDTO(1L, "Test", "test@test.com");
        given(customerService.createCustomer(any(CustomerDTO.class))).willReturn(savedDTO);
        // WHEN & THEN
        mockMvc.perform(post("/api/v1/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(validDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.name", is("Test")));
    }
}
