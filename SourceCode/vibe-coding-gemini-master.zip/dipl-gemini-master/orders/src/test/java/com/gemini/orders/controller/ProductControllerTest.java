package com.gemini.orders.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gemini.orders.dto.ProductDTO;
import com.gemini.orders.service.ProductService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ProductController.class)
class ProductControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private ProductService productService;

    @Test
    void shouldFetchProductById() throws Exception {
        // GIVEN
        long productId = 1L;
        ProductDTO productDTO = new ProductDTO(productId, "Test Proizvod", "Opis", new BigDecimal("99.99"), "Kategorija");
        given(productService.getProductById(productId)).willReturn(productDTO);

        // WHEN & THEN
        mockMvc.perform(get("/api/v1/products/{id}", productId))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.name", is("Test Proizvod")));
    }

    @Test
    void shouldCreateProduct() throws Exception {
        // GIVEN
        ProductDTO productToCreate = new ProductDTO(null, "Novi Proizvod", "Opis", new BigDecimal("150.00"), "Nova Kategorija");
        ProductDTO savedProduct = new ProductDTO(1L, "Novi Proizvod", "Opis", new BigDecimal("150.00"), "Nova Kategorija");
        given(productService.createProduct(any(ProductDTO.class))).willReturn(savedProduct);

        // WHEN & THEN
        mockMvc.perform(post("/api/v1/products")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(productToCreate)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id", is(1L)))
                .andExpect(jsonPath("$.name", is("Novi Proizvod")));
    }

    @Test
    void shouldFilterProducts() throws Exception {
        // GIVEN
        ProductDTO productDTO = new ProductDTO(1L, "Laptop", "Gaming laptop", new BigDecimal("1200.00"), "Elektronika");
        given(productService.getAllProducts("Elektronika", null, null, "asc"))
                .willReturn(Collections.singletonList(productDTO));

        // WHEN & THEN
        mockMvc.perform(get("/api/v1/products")
                        .param("category", "Elektronika")
                        .param("sortDir", "asc"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name", is("Laptop")))
                .andExpect(jsonPath("$[0].category", is("Elektronika")));
    }

    @Test
    void whenGetProductsWithFilter_shouldReturnFilteredList() throws Exception {
        // GIVEN
        ProductDTO product = new ProductDTO(1L, "Laptop", "opis", BigDecimal.TEN, "Elektronika");
        given(productService.getAllProducts("Elektronika", null, null, "asc"))
                .willReturn(List.of(product));
        // WHEN & THEN
        mockMvc.perform(get("/api/v1/products")
                        .param("category", "Elektronika")
                        .param("sortDir", "asc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].name", is("Laptop")));
    }
}