package com.gemini.orders.repository;

import com.gemini.orders.model.Product;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import java.math.BigDecimal;
import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
class ProductRepositoryTest {
    @Autowired private TestEntityManager entityManager;
    @Autowired private ProductRepository productRepository;

    @Test
    void whenSave_thenProductIsPersisted() {
        // GIVEN
        Product product = new Product();
        product.setName("Stolica");
        product.setPrice(new BigDecimal("250.00"));
        // WHEN
        Product savedProduct = productRepository.save(product);
        // THEN
        Product foundProduct = entityManager.find(Product.class, savedProduct.getId());
        assertThat(foundProduct).isNotNull();
        assertThat(foundProduct.getName()).isEqualTo("Stolica");
    }
}
