package com.gemini.orders.repository;

import com.gemini.orders.model.Customer;
import com.gemini.orders.model.Order;
import com.gemini.orders.model.OrderItem;
import com.gemini.orders.model.Product;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.domain.PageRequest;
import java.math.BigDecimal;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
class OrderItemRepositoryTest {
    @Autowired private TestEntityManager entityManager;
    @Autowired private OrderItemRepository orderItemRepository;

    @Test
    void whenFindTopSellingProducts_thenReturnAggregatedResultsInOrder() {
        // GIVEN
        Customer c = new Customer(); c.setName("C"); c.setEmail("c@e.com"); entityManager.persist(c);
        Product p1 = new Product(); p1.setName("P1"); p1.setPrice(BigDecimal.ONE); entityManager.persist(p1);
        Product p2 = new Product(); p2.setName("P2"); p2.setPrice(BigDecimal.ONE); entityManager.persist(p2);
        Product p3 = new Product(); p3.setName("P3"); p3.setPrice(BigDecimal.ONE); entityManager.persist(p3);

        // P1 sold: 5 + 10 = 15
        // P2 sold: 2
        // P3 sold: 8
        createOrder(c, List.of(new OrderItem(p1, 5), new OrderItem(p3, 8)));
        createOrder(c, List.of(new OrderItem(p1, 10), new OrderItem(p2, 2)));

        // WHEN
        List<Object[]> topProducts = orderItemRepository.findTopSellingProducts(PageRequest.of(0, 3));

        // THEN
        assertThat(topProducts).hasSize(3);
        // Check order and quantities
        assertThat(((Product) topProducts.get(0)[0]).getName()).isEqualTo("P1");
        assertThat(topProducts.get(0)[1]).isEqualTo(15L);

        assertThat(((Product) topProducts.get(1)[0]).getName()).isEqualTo("P3");
        assertThat(topProducts.get(1)[1]).isEqualTo(8L);

        assertThat(((Product) topProducts.get(2)[0]).getName()).isEqualTo("P2");
        assertThat(topProducts.get(2)[1]).isEqualTo(2L);
    }

    private void createOrder(Customer customer, List<OrderItem> items) {
        Order order = new Order();
        order.setCustomer(customer);
        for(OrderItem item : items) {
            item.setProduct(entityManager.find(Product.class, item.getProduct().getId()));
            order.addOrderItem(item);
        }
        entityManager.persist(order);
    }
}
