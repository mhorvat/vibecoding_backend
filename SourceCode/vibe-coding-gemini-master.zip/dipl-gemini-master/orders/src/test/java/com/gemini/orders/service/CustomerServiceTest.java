package com.gemini.orders.service;

import com.gemini.orders.dto.CustomerDTO;
import com.gemini.orders.exception.ResourceNotFoundException;
import com.gemini.orders.model.Customer;
import com.gemini.orders.repository.CustomerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerServiceTest {

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private CustomerService customerService;

    private Customer customer;
    private CustomerDTO customerDTO;

    @BeforeEach
    void setUp() {
        customer = new Customer();
        customer.setId(1L);
        customer.setName("Pero Peric");
        customer.setEmail("pero.peric@example.com");
        customerDTO = new CustomerDTO(1L, "Pero Peric", "pero.peric@example.com");
    }

    @Test
    void whenGetCustomerById_andCustomerExists_shouldReturnCustomerDTO() {
        // GIVEN
        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));
        // WHEN
        CustomerDTO result = customerService.getCustomerById(1L);
        // THEN
        assertThat(result).isEqualTo(customerDTO);
        verify(customerRepository).findById(1L);
    }

    @Test
    void whenGetCustomerById_andCustomerDoesNotExist_shouldThrowResourceNotFoundException() {
        // GIVEN
        when(customerRepository.findById(1L)).thenReturn(Optional.empty());
        // WHEN & THEN
        assertThrows(ResourceNotFoundException.class, () -> customerService.getCustomerById(1L));
        verify(customerRepository).findById(1L);
    }

    @Test
    void whenCreateCustomer_shouldReturnSavedCustomerDTO() {
        // GIVEN
        when(customerRepository.save(any(Customer.class))).thenReturn(customer);
        // WHEN
        CustomerDTO result = customerService.createCustomer(customerDTO);
        // THEN
        assertThat(result).isEqualTo(customerDTO);
        verify(customerRepository).save(any(Customer.class));
    }

    @Test
    void whenUpdateCustomer_shouldReturnUpdatedCustomerDTO() {
        // GIVEN
        CustomerDTO updatedInfo = new CustomerDTO(1L, "Pero Novi Peric", "pero.novi@example.com");
        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));
        when(customerRepository.save(any(Customer.class))).thenAnswer(invocation -> invocation.getArgument(0));
        // WHEN
        CustomerDTO result = customerService.updateCustomer(1L, updatedInfo);
        // THEN
        assertThat(result.name()).isEqualTo("Pero Novi Peric");
        assertThat(result.email()).isEqualTo("pero.novi@example.com");
        verify(customerRepository).save(any(Customer.class));
    }

    @Test
    void whenDeleteCustomer_shouldCallDeleteById() {
        // GIVEN
        when(customerRepository.existsById(1L)).thenReturn(true);
        doNothing().when(customerRepository).deleteById(1L);
        // WHEN
        customerService.deleteCustomer(1L);
        // THEN
        verify(customerRepository, times(1)).deleteById(1L);
    }
}
