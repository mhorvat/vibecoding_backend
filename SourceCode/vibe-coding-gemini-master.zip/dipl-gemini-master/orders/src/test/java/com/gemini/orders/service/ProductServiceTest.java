package com.gemini.orders.service;

import com.gemini.orders.dto.ProductDTO;
import com.gemini.orders.dto.TopProductDTO;
import com.gemini.orders.model.Product;
import com.gemini.orders.repository.OrderItemRepository;
import com.gemini.orders.repository.ProductRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;
    @Mock
    private OrderItemRepository orderItemRepository;

    @InjectMocks
    private ProductService productService;

    @Test
    void whenGetAllProducts_withFiltersAndSort_shouldCallFindAllWithCorrectSpecAndSort() {
        // GIVEN
        Product product = new Product();
        product.setId(1L);
        product.setName("Laptop");
        product.setCategory("Elektronika");
        product.setPrice(new BigDecimal("1200.00"));

        when(productRepository.findAll(any(Specification.class), any(Sort.class))).thenReturn(List.of(product));
        // WHEN
        List<ProductDTO> result = productService.getAllProducts("Elektronika", new BigDecimal("1000"), new BigDecimal("1500"), "desc");
        // THEN
        assertThat(result).hasSize(1);
        assertThat(result.get(0).name()).isEqualTo("Laptop");
        verify(productRepository).findAll(any(Specification.class), any(Sort.class));
    }

    @Test
    void whenGetTop5SellingProducts_shouldReturnCorrectlyMappedDTOs() {
        // GIVEN
        Product p1 = new Product(); p1.setId(1L); p1.setName("P1"); p1.setPrice(BigDecimal.TEN);
        Object[] record1 = {p1, 10L};

        List<Object[]> mockResults = new ArrayList<>();
        mockResults.add(record1);

        // Prosljeđujemo ispravno tipiziranu listu
        when(orderItemRepository.findTopSellingProducts(PageRequest.of(0, 5))).thenReturn(mockResults);

        // WHEN
        List<TopProductDTO> result = productService.getTop5SellingProducts();

        // THEN
        assertThat(result).hasSize(1);
        assertThat(result.get(0).product().name()).isEqualTo("P1");
        assertThat(result.get(0).totalQuantitySold()).isEqualTo(10L);
   }
}
