package com.gemini.orders.repository;

import com.gemini.orders.model.Customer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
class CustomerRepositoryTest {
    @Autowired private TestEntityManager entityManager;
    @Autowired private CustomerRepository customerRepository;

    @Test
    void whenFindById_thenReturnCustomer() {
        // GIVEN
        Customer customer = new Customer();
        customer.setName("Ana Anic");
        customer.setEmail("ana.anic@example.com");
        entityManager.persist(customer);
        entityManager.flush();
        // WHEN
        Customer found = customerRepository.findById(customer.getId()).orElse(null);
        // THEN
        assertThat(found).isNotNull();
        assertThat(found.getName()).isEqualTo(customer.getName());
    }
}
