package com.gemini.orders.service;

import com.gemini.orders.dto.CreateOrderRequest;
import com.gemini.orders.dto.OrderDTO;
import com.gemini.orders.exception.ResourceNotFoundException;
import com.gemini.orders.model.Customer;
import com.gemini.orders.model.Order;
import com.gemini.orders.model.Product;
import com.gemini.orders.repository.CustomerRepository;
import com.gemini.orders.repository.OrderRepository;
import com.gemini.orders.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderServiceTest {

    @Mock private OrderRepository orderRepository;
    @Mock private CustomerRepository customerRepository;
    @Mock private ProductRepository productRepository;

    @InjectMocks private OrderService orderService;

    private Customer customer;
    private Product product;
    private CreateOrderRequest createOrderRequest;

    @BeforeEach
    void setUp() {
        customer = new Customer(); customer.setId(1L); customer.setName("Test Kupac");
        product = new Product(); product.setId(101L); product.setName("Test Proizvod"); product.setPrice(new BigDecimal("50.00"));

        CreateOrderRequest.OrderItemRequest itemRequest = new CreateOrderRequest.OrderItemRequest(101L, 2);
        createOrderRequest = new CreateOrderRequest(1L, List.of(itemRequest));
    }

    @Test
    void whenCreateOrder_withValidData_shouldSucceed() {
        // GIVEN
        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));
        when(productRepository.findById(101L)).thenReturn(Optional.of(product));
        when(orderRepository.save(any(Order.class))).thenAnswer(invocation -> {
            Order o = invocation.getArgument(0);
            o.setId(99L);
            return o;
        });

        // WHEN
        OrderDTO result = orderService.createOrder(createOrderRequest);

        // THEN
        assertThat(result).isNotNull();
        assertThat(result.id()).isEqualTo(99L);
        assertThat(result.customerId()).isEqualTo(1L);
        assertThat(result.items()).hasSize(1);
        assertThat(result.items().get(0).productId()).isEqualTo(101L);
        assertThat(result.totalAmount()).isEqualTo(new BigDecimal("100.00"));
        verify(orderRepository).save(any(Order.class));
    }

    @Test
    void whenCreateOrder_withInvalidCustomerId_shouldThrowException() {
        // GIVEN
        when(customerRepository.findById(1L)).thenReturn(Optional.empty());
        // WHEN & THEN
        assertThrows(ResourceNotFoundException.class, () -> orderService.createOrder(createOrderRequest));
        verify(orderRepository, never()).save(any(Order.class));
    }
}