package com.gemini.orders.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gemini.orders.controller.OrderController;
import com.gemini.orders.dto.CreateOrderRequest;
import com.gemini.orders.dto.OrderDTO;
import com.gemini.orders.service.OrderService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(OrderController.class)
class OrderControllerTest {
    @Autowired private MockMvc mockMvc;
    @Autowired private ObjectMapper objectMapper;
    @MockBean private OrderService orderService;

    @Test
    void whenCreateOrder_withValidRequest_shouldReturnCreated() throws Exception {
        // GIVEN
        CreateOrderRequest.OrderItemRequest itemReq = new CreateOrderRequest.OrderItemRequest(1L, 2);
        CreateOrderRequest orderReq = new CreateOrderRequest(1L, List.of(itemReq));
        OrderDTO responseDTO = new OrderDTO(99L, LocalDateTime.now(), 1L, "Test Kupac", Collections.emptyList(), BigDecimal.TEN);
        given(orderService.createOrder(any(CreateOrderRequest.class))).willReturn(responseDTO);

        // WHEN & THEN
        mockMvc.perform(post("/api/v1/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(orderReq)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id", is(99)));
    }

    @Test
    void whenCreateOrder_withEmptyItems_shouldReturnBadRequest() throws Exception {
        // GIVEN
        CreateOrderRequest orderReq = new CreateOrderRequest(1L, Collections.emptyList());
        // WHEN & THEN
        mockMvc.perform(post("/api/v1/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(orderReq)))
                .andExpect(status().isBadRequest());
    }
}