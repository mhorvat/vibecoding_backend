package com.gemini.orders.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public record OrderDTO(
        Long id,
        LocalDateTime orderDate,
        Long customerId,
        String customerName,
        List<OrderItemDTO> items,
        BigDecimal totalAmount
) {}