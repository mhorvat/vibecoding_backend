package com.gemini.orders.service;

import com.gemini.orders.dto.ProductDTO;
import com.gemini.orders.dto.TopProductDTO;
import com.gemini.orders.exception.ResourceNotFoundException;
import com.gemini.orders.model.Product;
import com.gemini.orders.repository.OrderItemRepository;
import com.gemini.orders.repository.ProductRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {
    private final ProductRepository productRepository;
    private final OrderItemRepository orderItemRepository;

    public ProductService(ProductRepository productRepository, OrderItemRepository orderItemRepository) {
        this.productRepository = productRepository;
        this.orderItemRepository = orderItemRepository;
    }

    @Transactional(readOnly = true)
    public List<ProductDTO> getAllProducts(String category, BigDecimal minPrice, BigDecimal maxPrice, String sortDir) {
        // 1. Logika za sortiranje
        Sort sort = Sort.unsorted();
        if ("asc".equalsIgnoreCase(sortDir)) {
            sort = Sort.by(Sort.Direction.ASC, "price");
        } else if ("desc".equalsIgnoreCase(sortDir)) {
            sort = Sort.by(Sort.Direction.DESC, "price");
        }

        // 2. Logika za dinamičko filtriranje (Specification)
        Specification<Product> spec = Specification.where(null);

        if (category != null && !category.isEmpty()) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("category"), category));
        }
        if (minPrice != null) {
            spec = spec.and((root, query, cb) -> cb.greaterThanOrEqualTo(root.get("price"), minPrice));
        }
        if (maxPrice != null) {
            spec = spec.and((root, query, cb) -> cb.lessThanOrEqualTo(root.get("price"), maxPrice));
        }

        // 3. Izvršavanje upita
        return productRepository.findAll(spec, sort).stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ProductDTO getProductById(Long id) { return productRepository.findById(id).map(this::toDto).orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id)); }

    @Transactional
    public ProductDTO createProduct(ProductDTO productDTO) {
        Product product = new Product();
        product.setName(productDTO.name());
        product.setDescription(productDTO.description());
        product.setPrice(productDTO.price());
        product.setCategory(productDTO.category());
        return toDto(productRepository.save(product));
    }

    @Transactional
    public ProductDTO updateProduct(Long id, ProductDTO productDTO) {
        Product product = productRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
        product.setName(productDTO.name());
        product.setDescription(productDTO.description());
        product.setPrice(productDTO.price());
        product.setCategory(productDTO.category());
        return toDto(productRepository.save(product));
    }

    @Transactional
    public void deleteProduct(Long id) {
        if (!productRepository.existsById(id)) { throw new ResourceNotFoundException("Product not found with id: " + id); }
        productRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<TopProductDTO> getTop5SellingProducts() {
        List<Object[]> results = orderItemRepository.findTopSellingProducts(PageRequest.of(0, 5));

        return results.stream()
                .map(record -> {
                    Product product = (Product) record[0];
                    Long totalQuantity = (Long) record[1];
                    return new TopProductDTO(toDto(product), totalQuantity);
                })
                .collect(Collectors.toList());
    }

    private ProductDTO toDto(Product product) { return new ProductDTO(product.getId(), product.getName(), product.getDescription(), product.getPrice(), product.getCategory()); }
}