package com.gemini.orders.dto;

import java.math.BigDecimal;

public record OrderItemDTO(
        Long id,
        Long productId,
        String productName,
        int quantity,
        BigDecimal price
) {}