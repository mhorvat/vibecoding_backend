package com.gemini.orders.service;

import com.gemini.orders.dto.CreateOrderRequest;
import com.gemini.orders.dto.OrderDTO;
import com.gemini.orders.dto.OrderItemDTO;
import com.gemini.orders.exception.ResourceNotFoundException;
import com.gemini.orders.model.Customer;
import com.gemini.orders.model.Order;
import com.gemini.orders.model.OrderItem;
import com.gemini.orders.model.Product;
import com.gemini.orders.repository.CustomerRepository;
import com.gemini.orders.repository.OrderRepository;
import com.gemini.orders.repository.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final CustomerRepository customerRepository;
    private final ProductRepository productRepository;

    public OrderService(OrderRepository orderRepository, CustomerRepository customerRepository, ProductRepository productRepository) {
        this.orderRepository = orderRepository;
        this.customerRepository = customerRepository;
        this.productRepository = productRepository;
    }

    @Transactional
    public OrderDTO createOrder(CreateOrderRequest request) {
        Customer customer = customerRepository.findById(request.customerId())
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id: " + request.customerId()));

        Order order = new Order();
        order.setCustomer(customer);

        for (CreateOrderRequest.OrderItemRequest itemRequest : request.items()) {
            Product product = productRepository.findById(itemRequest.productId())
                    .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + itemRequest.productId()));

            OrderItem orderItem = new OrderItem();
            orderItem.setProduct(product);
            orderItem.setQuantity(itemRequest.quantity());
            order.addOrderItem(orderItem); // Pomoćna metoda sinkronizira vezu
        }

        Order savedOrder = orderRepository.save(order);
        return toDto(savedOrder);
    }

    @Transactional(readOnly = true)
    public OrderDTO getOrderById(Long id) {
        return orderRepository.findById(id).map(this::toDto)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id: " + id));
    }

    @Transactional(readOnly = true)
    public List<OrderDTO> getAllOrders() {
        return orderRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Transactional
    public void deleteOrder(Long id) {
        if (!orderRepository.existsById(id)) {
            throw new ResourceNotFoundException("Order not found with id: " + id);
        }
        orderRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<OrderDTO> getOrdersByCustomerId(Long customerId) {
        // Provjerimo postoji li korisnik (opcionalno, ali dobra praksa)
        if (!customerRepository.existsById(customerId)) {
            throw new ResourceNotFoundException("Customer not found with id: " + customerId);
        }

        return orderRepository.findByCustomerId(customerId).stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    private OrderDTO toDto(Order order) {
        List<OrderItemDTO> itemDTOs = order.getOrderItems().stream().map(item -> new OrderItemDTO(
                item.getId(),
                item.getProduct().getId(),
                item.getProduct().getName(),
                item.getQuantity(),
                item.getProduct().getPrice()
        )).collect(Collectors.toList());

        BigDecimal totalAmount = itemDTOs.stream()
                .map(item -> item.price().multiply(BigDecimal.valueOf(item.quantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return new OrderDTO(
                order.getId(),
                order.getOrderDate(),
                order.getCustomer().getId(),
                order.getCustomer().getName(),
                itemDTOs,
                totalAmount
        );
    }
}
