package com.gemini.orders.dto;

public record TopProductDTO(
        ProductDTO product,
        long totalQuantitySold
) {}
